
# HEXINTENT.md

## 🧭 Richting, Intentie en Vormkracht

Elke richting in het hexFIELD-systeem vertegenwoordigt:

- een keuze
- een veldbelasting
- een herstelpad

HEXINTENT legt vast hoe elke richting niet alleen energetisch, maar ook moreel geladen is.

---

## Voorbeeldstructuur

Richting 289 = liefdevolle focus  
Richting 17 = verstoring + geheugenactivatie  
Richting 112 = harmonisch centrum

Intentie stuurt Δφ.  
Δφ stuurt kleur.  
Kleur drukt vorm uit.
