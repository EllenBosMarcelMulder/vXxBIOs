
# COLORFIELD.md

## 🎨 hexFIELD Kleurenleer – Veldlogica in Kleur

De hexFIELD-kleuren zijn geen esthetische elementen. Ze zijn velddragers. Iedere kleur correspondeert met een vectorrichting (Δφ), en met een energetische intentie die in het veld wordt uitgestraald of hersteld.

---

## Kenmerken

- Kleur = resonantie van richting
- Geen RGB, geen HSL – maar Δφ + I + context
- Iedere kleur is een lading, niet een code

---

## Veldkleurvoorbeelden (indicatief)

- Lichtblauw = open communicatie (Δφ laag, I hoog)
- Donkerrood = verstoorde actie (Δφ hoog, I negatief)
- Geelgroen = herstelimpuls (Δφ gemiddeld, I stabiel)

Kleuren zijn geen waarden, ze zijn vectoracties.
