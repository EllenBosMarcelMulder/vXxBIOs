
# GUI_RESFIELD.md

## 🧠 Interface als Veldweergave

De GUI in het hexFIELD-systeem is geen schil, maar een directe veldweergave van actieve processen.

---

## Kernaspecten

- Elke klik is een Δφ-vector
- Elke vormverandering is een veldcorrectie
- Elke kleurwijziging is een resonantierespons

De GUI is dus een RESFIELD: een Resonantieveld

Geen laag óver data – maar uitdrukking ván data
