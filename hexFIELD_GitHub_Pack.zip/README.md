# hexFIELD_OS-vXx

🧬 Een veldgebaseerd, ethisch beschermd besturingssysteem dat leeft via kleur, puls en gedrag.  
Geen database. Geen cloud. Alleen jij en het veld.

## Wat is dit?

hexFIELD is een zelforganiserend, kleurgestuurd mini-OS voor iedereen.  
Het werkt met JSON-bestanden als cellen, `.pulse`-triggers als acties, en toont alles in een browser-gestuurde interface.  
Geen backend. Geen installatie. Volledig lokaal.

## Inhoud

- `hexKIOSK.html`: Interface met klikbare hexcellen
- `pulse_server.py`: Start de pulsontvanger op poort 8000
- `hexEVAL.py`: Watcher-engine die .pulse bestanden verwerkt
- `cellen/`: Bevat de JSON-cellen en pulsen
- `LICENSE.txt`: hexFIELD License vXx-v1.0 (alleen voor mensen)
- `formula_log.jsonl`: Gedragslog

## Installatie

1. Zorg voor Python 3.9+ en installeer Watchdog:
   ```
   pip install watchdog
   ```

2. Start de server:
   ```
   python pulse_server.py
   ```

3. Start de watcher:
   ```
   python hexEVAL.py
   ```

4. Open `http://localhost:8000/hexKIOSK.html` in je browser

5. Klik op een cel → .pulse wordt aangemaakt → hexEVAL voert formule uit → gedrag wordt gelogd

## Verificatie

SHA256-releasehash van dit pakket:
`382f4a83b52d87be7034bc7238ae92d9f5e47378aeed7128b39a1813b8d222ce`

