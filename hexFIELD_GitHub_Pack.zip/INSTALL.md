# INSTALLATIEHANDLEIDING

1. Download en unzip dit project op je computer

2. Installeer Python 3.9 of hoger via https://www.python.org/

3. Open een terminal / CMD in de map waar je dit project hebt geplaatst

4. Installeer `watchdog`:
   pip install watchdog

5. Start de lokale server:
   python pulse_server.py

6. Open een tweede terminal en start de evaluator:
   python hexEVAL.py

7. Open je browser op:
   http://localhost:8000/hexKIOSK.html

Klik op een cel om het veld te activeren.
