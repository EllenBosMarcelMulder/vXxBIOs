# hexCRZY.py
# Beschermt veldfuncties tegen ongeautoriseerd klikken

def hexCRZY(click_allowed):
    if not click_allowed:
        print("✗ hexCRZY actief – geen klik toegestaan.")
        return False
    print("✓ Klik toegestaan.")
    return True
