public class HexCRZY {
    public static boolean clickAllowed(boolean allowed) {
        if (!allowed) {
            System.out.println("✗ hexCRZY actief – klik geblokkeerd.");
            return false;
        }
        System.out.println("✓ Klik toegestaan.");
        return true;
    }
}
