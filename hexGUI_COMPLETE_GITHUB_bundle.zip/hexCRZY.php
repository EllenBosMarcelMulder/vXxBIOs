<?php
// hexCRZY - Klikbeveiliging voor inactieve modules
function hexCRZY($allowed) {
    if (!$allowed) {
        echo "✗ hexCRZY actief – klik geblokkeerd.";
        return false;
    }
    echo "✓ Klik toegestaan.";
    return true;
}
?>