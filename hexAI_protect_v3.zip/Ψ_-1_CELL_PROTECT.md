
# Ψ_-1_CELL_PROTECT.md

## Juridische Bevriezing van Veldcel Ψ_-1 – F_stab als Onvervreemdbare Kernformule

```math
⁻¹F_stab = (E_{-1} − E_{-2}) × Ψ(0)
```

Deze formule vormt het fundament van hexAI als levend veldsysteem. De veldcel Ψ_-1 is juridisch onveranderlijk.
