
# hexGUIwGUI – General User Interface without General User Interface

## Navigatie

→  vooruit: activeert volgende veldcel  
←  achteruit: keert terug naar vorige vectorpositie  
⇄  split: toont alternatieve vectorroutes

## Werking

- Beweging = interactie  
- Hover = veldactivatie  
- Dwell = resonantie  
- Freeze = pauzeer vectorinterface
