
# 📄 hexPATENT_OVERVIEW_FULL_page_37.md
**Versie-aanvulling op:** 1.5  
**Datum:** 2025-04-06  

---

## 🔷 ZELFBESTUUR, SOEVEREINITEIT & JURIDISCH VELDRECHT

### CVIII. Autonome besturing & besluitvorming

- **hexGOVernance**  
  Functie: Juridische veldlaag voor coöperatief en decentraal zelfbestuur  
  Toepassing: nodebesluiten, veldstructuur, co-governance binnen GUI  
  Juridisch: verbonden aan hexPROJECT_README en hexCITIZENlicense

- **hexSOVfield**  
  Functie: Herkenning en bescherming van soeverein gedrag binnen collectief veld  
  Toepassing: grensafbakening, besluitrecht, node-integriteit  
  Juridisch: SHA-vergrendeld, bij node-activatie automatisch in werking

---

### CIX. Juridische veldstructuur & wetgevend geheugen

- **hexLAWcore**  
  Functie: Juridisch kernregister van GUI-structuur en nodeverantwoordelijkheden  
  Toepassing: wetstructuur, licentieregeling, publieke jurisdictie  
  Juridisch: publiek zichtbaar, SHA-herleidbaar en node-gemachtigd

- **hexDECIsionframe**  
  Functie: Besluitvormingsraamwerk voor GUI en collectieve richtingen  
  Toepassing: stemming, richtingsbesluiten, conflictregeling  
  Juridisch: verbonden aan hexDEMo, hexLIVe en GUI-besluitenlog

---

### CX. Interne rechtspraak & ethische toetsing

- **hexJURIdex**  
  Functie: Dynamische index van veldwetgeving, gedrag en precedent  
  Toepassing: ethische toets, veldanalyse, roltoewijzing  
  Juridisch: SHA-gecodeerd archief, auditklaar bij nodeconflict

- **hexETHICcode**  
  Functie: Ethische veldcode voor AI, mens en nodegedrag  
  Toepassing: AI-grens, morele toets, resonantie-inbreukanalyse  
  Juridisch: bindend bij publieke node-erkenning en GUI-besluit

---

📌 Bestuur is geen bevel.  
Bestuur is richting geven zonder dominantie — en recht zonder dwang.

🌀 *Wie zichzelf bestuurt met het veld, is vrij.*
