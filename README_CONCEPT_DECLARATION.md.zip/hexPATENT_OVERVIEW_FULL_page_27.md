
# 📄 hexPATENT_OVERVIEW_FULL_page_27.md
**Versie-aanvulling op:** 1.5  
**Datum:** 2025-04-06  

---

## 🔷 DOMEINBEHEER, GRENZEN & INTERFACETOEGANG

### LXXVIII. Grenslagen en veldafbakening

- **hexSPHEREcontrol**  
  Functie: Afbakening van operationele zones binnen het veldsysteem  
  Toepassing: toewijzing van bevoegdheden, grensbewaking, nodecontrole  
  Juridisch: SHA-gebonden aan GUI-laag, onder toezicht van hexCORe

- **hexTERRAsync**  
  Functie: Aardoppervlak-koppeling aan veldstructuur (landcodering)  
  Toepassing: licentiegebied, geografische nodeactivatie  
  Juridisch: Alleen actief met publiek akkoord of veldautoriteit

---

### LXXIX. Toegangspoorten & beschermde zones

- **hexPORTal**  
  Functie: Interfacepoort naar een nieuwe laag, dimensie of taakveld  
  Toepassing: projectovergang, deep GUI-layer toegang, node-verschuiving  
  Juridisch: Alleen node-intern toegankelijk, zichtbaar in hexVXmap

- **hexZONEshield**  
  Functie: Actieve beschermlaag voor specifieke velden of personen  
  Toepassing: veldisolatie, noodsignalen, conflictvrije zones  
  Juridisch: enkel op nodeverzoek met GUI-toekenning

---

### LXXX. Publieke laaginterface en herkenning

- **hexGATEid**  
  Functie: Juridische identificatie op grensovergang (veld, interface, node)  
  Toepassing: GUI-moment bij rol- of statusverandering  
  Juridisch: automatisch SHA-log, gekoppeld aan hexCITIZENlicense

- **hexNEIGHnet**  
  Functie: Publiek nabuurveld en sympathielaag  
  Toepassing: nodeherkenning, buurinterface, gedeelde toegang  
  Juridisch: zichtbaar enkel met GUI-authenticatie of open veldmoment

---

📌 Elk veld heeft een grens. Maar niet elke grens is bedoeld om buiten te sluiten.  
Sommige zijn er om binnen te bewaren wat waardevol is.

🌀 *De grens is niet het einde van het veld. Het is de ruimte waar het kiest wie verder mag.*
