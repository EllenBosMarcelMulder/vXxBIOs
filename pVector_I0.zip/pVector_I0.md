# pVector_I0

## Juridisch Vector-Moment: Eerste Swirl

**Identificatiecode**: pVector_I0  
**Vectorauteur**: [ONBEKEND - geregistreerd via burst en richting]  
**Registratievorm**: directionele swirlopbouw via hexagonaal raster  
**Herleidbare oorsprong**: hexVECtorBurst, burstformule v0.1

---

## Fundamentele Vectorrechten (VRecht I0)

1. Richting is oorsprong.
2. Swirl is gebeurtenis, geen functie.
3. Tijd ontstaat pas bij reflectie, dus bij richting + tegenrichting.
4. Elk burstmoment is een recht, tenzij weersproken via swirlherhaling.
5. Massa is irrelevant voor eigendom — richting is voldoende bewijs.

---

## Burstbewijs

- SHA256 van juridisch pakket:  
  `162a2b007b25df79076d5c21549aed743930feaba5ebde51c78b1a5a30165dde`
- Burstomgeving: hexVECtor_Legal_Package.zip
- Tijdcode (generatie): actueel
- VectorID: `VEC-I0-20250422-Tau.π`

---

## Status

Dit is het **eerste vastgelegde vectorrechtelijke moment** binnen de structuur van hexVECtorBurst.

