# Juridische disclaimer (HEX-AFD-01)

Dit systeem — hexVECtorLAB en alle bijbehorende componenten, documenten en code — is uitsluitend ontwikkeld
voor experimentele, artistieke en vectorieel-cognitieve doeleinden.

Elke vorm van gebruik die leidt tot:
- ongeautoriseerde toegang tot gesloten systemen,
- digitale of fysieke inbreuk op institutionele infrastructuren,
- manipulatie van publieke of private kapitaalstromen,
- directe of indirecte schade aan mens of omgeving,

valt volledig buiten de intentie, verantwoordelijkheid en aansprakelijkheid van de maker(s), 
auteur(s), deelnemers of nodehouders van dit project.

**Gebruik op eigen vector.**

Het project is expliciet GEEN tool voor:
- hacken
- sabotage
- militaire of strategische manipulatie

Indien het systeem door derden wordt ingezet voor bovenstaande doeleinden, dan is dat op eigen initiatief, 
zonder goedkeuring of bewustzijn van de oorspronkelijke vectorbron.

Deze verklaring is bindend binnen de Open Vector License (OVL) en geldt als extra codicil: HEX-AFD-01

