# GUI voor het interactie met het Hashpulse-systeem
import tkinter as tk

class HashpulseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hashpulse Control Interface")
        
        self.label = tk.Label(root, text="Activeer Hashpulse Systeem", font=("Arial", 14))
        self.label.pack()
        
        self.activate_button = tk.Button(root, text="Start Server", command=self.start_server)
        self.activate_button.pack()
        
    def start_server(self):
        print("Server gestart via Hashpulse!")
        # Call to actual function that starts the system based on the hashpulse
