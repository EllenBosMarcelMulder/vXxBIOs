import hashlib

def generate_hash(data):
    """
    Genereer een hash voor de gegeven data.
    """
    return hashlib.sha256(data.encode('utf-8')).hexdigest()

def detect_pulse(hash_data):
    pulse_type = hash_data['metadata']['pulse_type']
    activation_conditions = hash_data['metadata']['activation_conditions']
    
    if check_conditions(activation_conditions):
        if pulse_type == 'start':
            start_process(hash_data['data']['action'])

def check_conditions(activation_conditions):
    if activation_conditions['state'] == 'idle':
        return True
    return False

def start_process(action):
    if action == "start_llama_server()":
        start_llama_server()

def start_llama_server():
    print("Starting Llama server...")
