import os
import hashlib
import json
from langdetect import detect
from collections import Counter
from pathlib import Path

STANDARD_MAP = {
    "doc": "#vXx.bodydoc",
    "docx": "#vXx.bodydoc",
    "pdf": "#vXx.bodydoc",
    "mp3": "#vXx.audio",
    "wav": "#vXx.audio",
    "mp4": "#vXx.videovoice",
    "mov": "#vXx.videovoice",
    "jpg": "#vXx.imageEXIF",
    "jpeg": "#vXx.imageEXIF",
    "png": "#vXx.imageEXIF",
    "html": "#vXx.code.html",
    "py": "#vXx.code.py",
    "php": "#vXx.code.php",
    "java": "#vXx.code.java",
    "json": "#vXx.semanticweb",
    "rdf": "#vXx.refRDF",
    "xml": "#vXx.legal"
}

def hash_file(filepath):
    with open(filepath, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def read_text_body(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return ""

def analyze_text(text):
    lang = detect(text)
    words = text.split()
    wordcount = Counter(words)
    linked = {word: [w for w in words if w != word] for word in words}
    return lang, dict(wordcount), linked

def classify_filetype(filepath):
    ext = Path(filepath).suffix[1:].lower()
    return STANDARD_MAP.get(ext, "#vXx.unknown")

def extract_metadata(filepath):
    basename = os.path.basename(filepath)
    fhash = hash_file(filepath)
    text = read_text_body(filepath)
    lang, wc, links = analyze_text(text)
    ftype = classify_filetype(filepath)

    return {
        "filename": basename,
        "hash": fhash,
        "fieldtype": ftype,
        "language": lang,
        "wordcount": wc,
        "wordlinks": links,
        "metaTEMPLATE": f"{ftype}_TEMPLATE_001" if "doc" in ftype else None
    }

def export_to_hex(filepaths, output_json="hexMETA_output.json"):
    full_report = {
        "hexMTH": {"versie": "1.0", "bestanden": []},
        "hexMETA_TOTAL": []
    }

    for path in filepaths:
        meta = extract_metadata(path)
        full_report["hexMTH"]["bestanden"].append(meta["filename"])
        full_report["hexMETA_TOTAL"].append(meta)

    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(full_report, f, indent=2, ensure_ascii=False)

    return output_json

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Gebruik: python hexMETA_UNIVERSE_detectTOTAL.py <bestand1> <bestand2> ...")
        sys.exit(1)

    files = sys.argv[1:]
    result = export_to_hex(files)
    print(f"#vX#tTOTAL metadata geëxporteerd naar: {result}")
