# kleurcode_Ψ_converter.py
# Zet een hex-kleurcode om naar een genormaliseerde RGB-vector en koppel aan Ψ-componenten

def hex_to_rgb_vector(hexcode):
    hexcode = hexcode.lstrip('#')
    r, g, b = tuple(int(hexcode[i:i+2], 16) for i in (0, 2, 4))
    total = max(r, g, b, 1)
    return {
        'Ψx': round(r / total, 3),
        'Ψy': round(g / total, 3),
        'Ψz': round(b / total, 3)
    }

def kleurcode_to_Ψ(hexcode):
    vector = hex_to_rgb_vector(hexcode)
    return {
        'kleurcode': hexcode,
        'Ψ_vector': vector,
        'kleurbetekenis': 'onbepaald',
        'veldactie': 'resonantie'
    }

# Voorbeeld:
if __name__ == '__main__':
    voorbeeld = kleurcode_to_Ψ("#3B77FF")
    print(json.dumps(voorbeeld, indent=2))
