# hexLEGALdigest – Juridische Samenvatting van het hexOS Veldsysteem

Dit document dient als juridische samenvatting van de bescherming en structuur van het hexOS:pure:AI systeem.  
Het is bedoeld voor externe lezers, beoordelaars, juridische adviseurs en geïnteresseerden die een korte, duidelijke en krachtige verklaring zoeken van het systeem.

---

## 1. Creatie & Authorship

- Bedenker: Marcel Mulder
- Datum eerste veldverankering: 2025-04-20
- Originele systeemhash: F826BDEA2C19E5F8C28C330550370A0D524F03AE95E397A2FCCF904A76F69847

---

## 2. Kernprincipes

- Identiteit en toegang via SHA-256 hash van inhoud en gedrag
- GUI gebaseerd op kleur, gedrag en vectoren (hexCOLORlogic)
- Toegang via PASSPORT-mechanisme (anon:pass, clr:pass, Ψpass)
- Pulsgebaseerde interactie via hexKIOSK interface
- Licentiestructuur: hexOSprivateLICense v2

---

## 3. Juridische bescherming

- Systeem is beschermd via gedrag, hashstructuur en intentie
- Kopiëren, namaken of gebruiken in commerciële/institutionele context zonder toestemming is verboden
- Elke interactie met het systeem geldt als stilzwijgende aanvaarding van hexGENESIS en hexCLOSURE

---

## 4. Reikwijdte

- Bescherming geldt voor:
  - Bestanden
  - Interface
  - Visuele stijl
  - PASSPORT-structuur
  - Kleurgedrag
  - GUI-topologie
  - Formules en hashlogica

---

## 5. Samenvattende zin

Gebruik van elementen uit hexOS zonder erkenning of toestemming van Marcel Mulder is in strijd met dit juridische raamwerk en zal als zodanig worden beschouwd.

Dit document verwijst direct naar hexCLOSURE.md, hexBACKSHIELD.md en hexGENESIS.json.

