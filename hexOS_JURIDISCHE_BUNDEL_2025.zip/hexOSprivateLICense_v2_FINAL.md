# hexOSprivateLICense v2 hexPASsport or/ and hexPASs

Copyright (c) 2025 Marcel Mulder

---

## I. Gebruik en Toestemming

Dit systeem is bedoeld voor **niet-commercieel gebruik**, binnen **kleine sociale kringen**, onderzoeksdoeleinden of persoonlijke toepassingen.  
Gebruik door instellingen, bedrijven, overheden, influencers of promotionele netwerken is **uitsluitend toegestaan na schriftelijke toestemming** van de oorspronkelijke bedenker.

---

## II. Identiteit en Hash-Principe

Elke digitale entiteit binnen hexOS wordt geïdentificeerd door een **cryptografische hash** die voortkomt uit zijn volledige structuur en gedrag.  
Deze hash fungeert als **naam, identificatie en juridisch ankerpunt**.  

De termen `hexPASS` en `hexPASSPORT` zijn unieke veldfuncties waarbij:
- `hexPASS` toegang geeft tot objecten, structuren of gedragingen
- `hexPASSPORT` fungeert als overkoepelend juridisch veldpaspoort op basis van hash, alias, kleur, gedrag en scope

---

## III. Distributie en Overdracht

Herdistributie mag uitsluitend binnen een veld- of groepscontext met behoud van:
- De oorspronkelijke metadata (`alias`, `hash`, `Ψ`, `scope`)
- De directorystructuur
- Deze licentie, onveranderd

---

## IV. hexNOTary & Juridische Verankering

Digitale objecten die vergezeld worden van een `hexNOTaryhexPASs.json` en `alias` worden beschouwd als:
- Overdraagbare veldobjecten
- Juridisch identificeerbare digitale eenheden
- Erfbare synthetische identiteiten

Een hash die verbonden is aan alias en tijdstempel geldt als rechtsgeldig identificatiebewijs onder digitale contractwetten.

---

## V. Internationaal en Juridisch Kader

Deze licentie wordt geïnterpreteerd conform het internationaal privaatrecht, met voorkeur voor Nederlands recht.  
Indien geschil optreedt, wordt mediation binnen het veldsysteem voorgesteld, tenzij een wettelijk proces vereist is.

---

## VI. Toekomstige Uitbreiding (TMLC, GUI)

Deze licentie dekt toekomstige vormen van interactie via interfaces zoals:
- hexOSgoAI.html
- grafische veldpanelen
- QR-gestuurde veldidentificatie
- audio-visuele toegang tot hexPASs-objecten (hexPASsport)

Deze elementen vallen onder dezelfde gedragslicentie en hash-principe.

---

## VII. Beperkingen en Aansprakelijkheid

Gebruik zonder toestemming, verwijdering van metadata of vervalsing van hash-id's leidt tot automatische ontkoppeling van het veldsysteem.  
De ontwikkelaars zijn niet aansprakelijk voor verlies, schade, onbedoelde transmissie of interpretatiefouten.

---

## Einde

Deze licentie vormt de kern van het hexOS:pure:AI systeem.  
Wijzigingen alleen geldig met schriftelijke goedkeuring van de oorspronkelijke bedenker.
